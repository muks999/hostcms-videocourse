<?php
/**
 * Market.
 *
 * @package HostCMS
 * @version 6.x
 * @author Hostmake LLC
 * @copyright © 2005-2016 ООО "Хостмэйк" (Hostmake LLC), http://www.hostcms.ru
 */
require_once('../../bootstrap.php');

Core_Auth::authorization($sModule = 'market');

$sAdminFormAction = '/admin/market/index.php';

$category_id = intval(Core_Array::getRequest('category_id'));

// Контроллер формы
$oAdmin_Form_Controller = Admin_Form_Controller::create();
$oAdmin_Form_Controller
	->module(Core_Module::factory($sModule))
	->setUp()
	->path($sAdminFormAction)
	->title(Core::_('Market.title'))
	->setAdditionalParam($category_id ? 'category_id=' . $category_id : '');

ob_start();

$oMarket_Controller = Market_Controller::instance();
$oMarket_Controller
	->controller($oAdmin_Form_Controller)
	->setMarketOptions()
	->category_id($category_id)
	->page($oAdmin_Form_Controller->getCurrent());

$oAdmin_View = Admin_View::create()->module(Core_Module::factory($sModule));

$category_id
	&& $oMarket_Controller->order('price');

// Установка модуля
if (Core_Array::getRequest('install'))
{
	try
	{
		$oModule = $oMarket_Controller->getModule(intval(Core_Array::getRequest('install')));

		if (is_object($oModule))
		{
			$oAdminModule = Core_Entity::factory('Module')->getByPath($oModule->path, FALSE);

			if (is_null($oAdminModule))
			{
				// Устанавливать сейчас
				$bInstall = FALSE;

				// Читаем modules.xml
				$oModuleXml = $oMarket_Controller->parseModuleXml();

				if (is_object($oModuleXml))
				{
					$aXmlFields = $oModuleXml->xpath("fields/field");

					if (count($aXmlFields))
					{
						// Вывод списка опций
						if ($oAdmin_Form_Controller->getAction() != 'sendOptions')
						{
							$oMarket_Controller->showModuleOptions();

							$sTitle = Core::_('Market.module-options', $oModule->name);
							$oAdmin_View->pageTitle($sTitle);
							$oMarket_Controller->controller->title($sTitle);
						}
						// Применение списка преданных опций
						else
						{
							// было применение опций
							$oMarket_Controller->applyModuleOptions();

							$bInstall = TRUE;
						}
					}
					else
					{
						// Устанавливаем сразу без опций модуля
						$bInstall = TRUE;
					}
				}
				else
				{
					// Устанавливаем сразу без опций модуля
					$bInstall = TRUE;
				}

				if ($bInstall)
				{
					$oMarket_Controller->install();

					$oAdmin_View->addMessage(
						Core_Message::get(Core::_('Market.install_success', $oModule->name))
					);

					// Вывод списка
					$oMarket_Controller
						->getMarket()
						->showItemsList();
				}
			}
			else
			{
				$oAdmin_View->addMessage(
					Core_Message::get(Core::_('Market.module-was-installed', $oModule->name), 'error')
				);

				// Вывод списка
				$oMarket_Controller
					->getMarket()
					->showItemsList();
			}
		}
		else
		{
			$oAdmin_View->addMessage(
				Core_Message::get(Core::_('Market.server_error_respond_12'), 'error')
			);
		}
	}
	catch (Exception $e)
	{
		$oAdmin_View->addMessage(
			Core_Message::get($e->getMessage(), 'error')
		);

		// Вывод списка
		$oMarket_Controller
			->getMarket()
			->showItemsList();
	}
}
else
{
	try
	{
		$oAdmin_View->pageTitle(Core::_('Market.title'));

		// Вывод списка
		$oMarket_Controller
			->getMarket()
			->showItemsList();
	}
	catch (Exception $e)
	{
		$oAdmin_View->addMessage(
			Core_Message::get($e->getMessage(), 'error')
		);
	}
}

$oAdmin_View->content(ob_get_clean());

ob_start();
$oAdmin_View->show();

Core_Skin::instance()
	->answer()
	->ajax(Core_Array::getRequest('_', FALSE))
	->content(ob_get_clean())
	->message($oAdmin_View->message)
	->title(Core::_('Market.title'))
	->module($sModule)
	->execute();