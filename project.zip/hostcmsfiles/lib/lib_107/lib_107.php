<?php
$code = Core_Array::get(Core_Page::instance()->widgetParams, 'code');
echo $code;