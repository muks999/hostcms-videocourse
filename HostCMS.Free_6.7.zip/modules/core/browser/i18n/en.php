<?php

return array(
	'title' => 'You are using an outdated browser',
	'description' => 'For a better experience using this site, please upgrade to a modern web browser.',
);