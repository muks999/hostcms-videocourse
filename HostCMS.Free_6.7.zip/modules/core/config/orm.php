<?php

return array (
	'cache' => 'memory',
	'columnCache' => 'memory'
);