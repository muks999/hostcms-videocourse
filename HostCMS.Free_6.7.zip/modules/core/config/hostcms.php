<?php

return array (
	'hostcms' => 3602775533,
	'integration' => 0
);