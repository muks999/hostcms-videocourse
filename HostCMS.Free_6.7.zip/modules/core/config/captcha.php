<?php

return array (
	'allowedCharacters' => '1234567890', // 23456789abcdeghkmnpqsuvxyz
	//'color' => array(0, 0, 0),
	//'backgroundColor' => array(255, 255, 255),
	//'noise' => 10,
	//'width' => 88,
	//'height' => 31,
	'minLenght' => 4,
	'maxLenght' => 4,
	'fillBackground' => TRUE,
);