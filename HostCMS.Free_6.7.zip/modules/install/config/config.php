<?php

return array (
	'lng' => array(
		'ru' => 'Русский',
		'en' => 'English',
	),
);