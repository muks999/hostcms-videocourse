var i18n =
{
"Minimum": "Required minimum ",
"Maximum": "Possible maximum",
"one_letter": "letter",
"some_letter1": "letters",
"some_letter2": "letters",
"current_length": "Current length is",
"wrong_value_format": "Wrong value format.",
"different_fields_value": "The fields value are different"
};