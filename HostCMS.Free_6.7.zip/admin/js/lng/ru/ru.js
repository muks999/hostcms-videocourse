var i18n =
{
"Minimum": "Минимум",
"Maximum": "Максимум",
"one_letter": "символ",
"some_letter1": "символов",
"some_letter2": "символа",
"current_length": "Текущая длина &mdash;",
"wrong_value_format": "Значение поля не соответствует формату.",
"different_fields_value": "Значения полей различны."
};